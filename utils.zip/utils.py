import os

from openai import OpenAI
from xhtml2pdf import pisa
from io import BytesIO





client = OpenAI(api_key="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")


def generate_resume(name, email, phone, job_title, company, experience, skills, education):
    prompt = f"""
Generate a professional resume in Markdown format with the following details:

Full Name: {name}
Email: {email}
Phone: {phone}
Job Title: {job_title}
Company: {company}
Experience: {experience}
Skills: {skills}
Education: {education}

Make it well structured with headings like Objective, Skills, Experience, and Education.
"""
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )
    return response.choices[0].message.content.strip()


def generate_cover_letter(name, email, phone, job_title, company, experience, skills, education):
    prompt = f"""
Write a formal and enthusiastic cover letter in Markdown format using these details:

Full Name: {name}
Email: {email}
Phone: {phone}
Job Title: {job_title}
Company: {company}
Experience: {experience}
Skills: {skills}
Education: {education}

It should include a greeting, role interest, highlighted skills, and a positive closing.
"""
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )
    return response.choices[0].message.content.strip()


def convert_to_pdf(content_md, output_file="output.pdf"):
    html_content = f"<html><body><pre>{content_md}</pre></body></html>"
    result = BytesIO()
    pisa_status = pisa.CreatePDF(html_content, dest=result)
    if pisa_status.err:
        return None
    return result.getvalue()
